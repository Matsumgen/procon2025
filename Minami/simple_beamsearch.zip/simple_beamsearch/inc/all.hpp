#ifndef ALL_HPP
#define ALL_HPP 0
#include "main.hpp"
#include "algo.hpp"
#include "utilities.hpp"
#include "segment_tree"
#include "trie.hpp"
#endif